# AMBA Client (Fabric, Minecraft 1.21.11)

Modules: ChunkFinder, StorageESP, StashFinder, AdvStashFinder, AmethystESP, Freecam, SpeedMine, BreakDelay.

## Build
1. Open https://fabricmc.net/develop , choose 1.21.11, and copy the current
   `loader_version`, `loom_version` and `fabric_version` into `gradle.properties`.
2. Add the Gradle wrapper (run `gradle wrapper` once, or copy `gradlew`, `gradlew.bat` and `gradle/` from the
   official template).  Java 21 required.
3. `./gradlew build`  ->  `build/libs/amba-client-1.0.0.jar`  ->  drop into `.minecraft/mods` with Fabric API.

## Use
Right Shift or the chat command `/amba` opens (and closes) the menu. Click a module to toggle it, click a setting to step its value.
Advanced stash hits are appended to `<game dir>/amba_stashes.txt`.

## If it does not compile (1.21.x renames things often)
- `Util.handle()`            window handle accessor
- `HudRenderCallback`        replace with `HudElementRegistry.attachElementAfter(...)`
- `MultiPlayerGameModeAccessor` field names (`destroyDelay`, `destroyProgress`)
- `Esp.project`              `Vec3.x/y/z` fields vs `x()/y()/z()` if Vec3 became a record

## Getting the .jar without installing anything
Push this folder to a GitHub repo -> Actions tab -> "build" -> download the `amba-client-jar` artifact.
Use the jar WITHOUT `-sources` in its name.
