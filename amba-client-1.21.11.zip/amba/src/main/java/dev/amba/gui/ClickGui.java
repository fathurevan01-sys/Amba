package dev.amba.gui;

import dev.amba.module.Module;
import dev.amba.module.ModuleManager;
import dev.amba.module.Setting;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/** Left-click a module to toggle it; left-click a setting to step it (wraps around). */
public class ClickGui extends Screen {
    public ClickGui() { super(Component.literal("AMBA")); }

    private static String label(Module m) { return (m.enabled ? "\u00a7a" : "\u00a77") + m.name; }

    @Override
    protected void init() {
        int y = 30;
        for (Module m : ModuleManager.MODULES) {
            Button toggle = Button.builder(Component.literal(label(m)), b -> {
                m.toggle();
                b.setMessage(Component.literal(label(m)));
            }).bounds(20, y, 130, 20).build();
            addRenderableWidget(toggle);

            int x = 156;
            for (Setting s : m.settings) {
                Button sb = Button.builder(Component.literal(s.name + ": " + s.display()), b -> {
                    s.cycle();
                    b.setMessage(Component.literal(s.name + ": " + s.display()));
                }).bounds(x, y, 104, 20).build();
                addRenderableWidget(sb);
                x += 108;
            }
            y += 24;
        }
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float delta) {
        g.fill(0, 0, width, height, 0x90000000);
        g.drawString(font, "AMBA Client  -  Caps Lock, Right Shift, ` or /amba", 20, 12, 0xFFB98CFF, true);
        super.render(g, mouseX, mouseY, delta);
    }

    @Override public boolean isPauseScreen() { return false; }
}
