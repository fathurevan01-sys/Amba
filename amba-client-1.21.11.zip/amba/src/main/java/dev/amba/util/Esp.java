package dev.amba.util;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/**
 * Screen-space ESP: projects world boxes onto the HUD. Works through walls, follows the
 * camera entity (so it also works in freecam), and avoids touching the render pipeline.
 */
public final class Esp {
    private Esp() {}

    public static double[] project(Vec3 p, float pt) {
        Minecraft mc = Minecraft.getInstance();
        Entity c = mc.getCameraEntity();
        if (c == null) return null;
        Vec3 cam = c.getEyePosition(pt);
        double yaw = Math.toRadians(c.getViewYRot(pt));
        double pitch = Math.toRadians(c.getViewXRot(pt));
        double cp = Math.cos(pitch);
        double fx = -Math.sin(yaw) * cp, fy = -Math.sin(pitch), fz = Math.cos(yaw) * cp;
        double rx = -Math.cos(yaw), ry = 0, rz = -Math.sin(yaw);
        double ux = ry * fz - rz * fy, uy = rz * fx - rx * fz, uz = rx * fy - ry * fx;
        double dx = p.x - cam.x, dy = p.y - cam.y, dz = p.z - cam.z;
        double z = dx * fx + dy * fy + dz * fz;
        if (z < 0.05) return null;
        double x = dx * rx + dy * ry + dz * rz;
        double y = dx * ux + dy * uy + dz * uz;
        int w = mc.getWindow().getGuiScaledWidth(), h = mc.getWindow().getGuiScaledHeight();
        double t = Math.tan(Math.toRadians(mc.options.fov().get()) / 2.0);
        double sx = w / 2.0 + x / (z * t * ((double) w / h)) * (w / 2.0);
        double sy = h / 2.0 - y / (z * t) * (h / 2.0);
        return new double[]{sx, sy, z};
    }

    public static double distTo(Vec3 p, float pt) {
        Entity c = Minecraft.getInstance().getCameraEntity();
        return c == null ? 0 : c.getEyePosition(pt).distanceTo(p);
    }

    public static void box(GuiGraphics g, AABB b, int color, String label, float pt) {
        double minX = 1e9, minY = 1e9, maxX = -1e9, maxY = -1e9;
        for (int xi = 0; xi < 2; xi++)
            for (int yi = 0; yi < 2; yi++)
                for (int zi = 0; zi < 2; zi++) {
                    double[] s = project(new Vec3(xi == 0 ? b.minX : b.maxX,
                            yi == 0 ? b.minY : b.maxY, zi == 0 ? b.minZ : b.maxZ), pt);
                    if (s == null) return; // any corner behind camera: skip
                    minX = Math.min(minX, s[0]); maxX = Math.max(maxX, s[0]);
                    minY = Math.min(minY, s[1]); maxY = Math.max(maxY, s[1]);
                }
        int x1 = (int) minX, y1 = (int) minY, x2 = (int) maxX, y2 = (int) maxY;
        if (x2 - x1 > 4000 || y2 - y1 > 4000) return;
        g.fill(x1, y1, x2, y2, (color & 0x00FFFFFF) | 0x28000000);
        g.fill(x1, y1, x2, y1 + 1, color);
        g.fill(x1, y2 - 1, x2, y2, color);
        g.fill(x1, y1, x1 + 1, y2, color);
        g.fill(x2 - 1, y1, x2, y2, color);
        if (label != null)
            g.drawString(Minecraft.getInstance().font, label, x1, y1 - 10, color, true);
    }
}
