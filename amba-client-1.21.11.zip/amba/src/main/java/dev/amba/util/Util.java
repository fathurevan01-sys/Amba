package dev.amba.util;

import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

public final class Util {
    private Util() {}

    /** Single fix-point if the window handle accessor is named differently. */
    public static long handle() {
        return Minecraft.getInstance().getWindow().handle();
    }

    public static boolean keyDown(int glfwKey) {
        return GLFW.glfwGetKey(handle(), glfwKey) == GLFW.GLFW_PRESS;
    }

    public static void chat(String msg) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null)
            mc.player.displayClientMessage(Component.literal("\u00a75[AMBA]\u00a7r " + msg), false);
    }

    public static long key(int cx, int cz) {
        return ((long) cx << 32) | (cz & 0xFFFFFFFFL);
    }
}
