package dev.amba.module;

import dev.amba.mixin.MultiPlayerGameModeAccessor;

/** Caps the cooldown between finishing one block and starting the next (vanilla = 5 ticks). */
public class BreakDelay extends Module {
    private final Setting delay = num("Delay", 0, 0, 5, 1);

    public BreakDelay() { super("BreakDelay"); }

    @Override
    public void onTick() {
        if (mc.gameMode == null) return;
        MultiPlayerGameModeAccessor a = (MultiPlayerGameModeAccessor) mc.gameMode;
        if (a.zGetDestroyDelay() > delay.i()) a.zSetDestroyDelay(delay.i());
    }
}
