package dev.amba.module;

import dev.amba.util.Esp;
import dev.amba.util.Util;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.phys.AABB;

import java.util.HashSet;
import java.util.Set;

/** Flags any chunk with at least N chests/barrels/shulkers. */
public class StashFinder extends Module {
    private final Setting min = num("MinStorage", 10, 3, 60, 1);
    private final Setting chat = num("Chat", 1, 0, 1, 1);
    private final Set<Long> reported = new HashSet<>();
    private int ver = -1;

    public StashFinder() { super("StashFinder"); }
    @Override public boolean usesScanner() { return true; }
    @Override public void onEnable() { reported.clear(); ver = -1; }

    @Override
    public void onTick() {
        if (ver == Scanner.version) return;
        ver = Scanner.version;
        if (!chat.on()) return;
        for (Scanner.Chunk c : Scanner.chunks.values())
            if (c.storage() >= min.i() && reported.add(c.key()))
                Util.chat("Stash: chunk " + c.cx + "," + c.cz + " (~" + c.blockX() + ", " + c.blockZ() + ") storage=" + c.storage());
    }

    @Override
    public void onHud(GuiGraphics g, float pt) {
        for (Scanner.Chunk c : Scanner.chunks.values()) {
            if (c.storage() < min.i()) continue;
            AABB b = new AABB(c.cx * 16, c.minY, c.cz * 16, c.cx * 16 + 16, c.maxY + 1, c.cz * 16 + 16);
            Esp.box(g, b, 0xFFFFAA00, "STASH " + c.storage(), pt);
        }
    }
}
