package dev.amba.module;

public class Setting {
    public final String name;
    public double value;
    private final double min, max, step;

    public Setting(String name, double def, double min, double max, double step) {
        this.name = name; this.value = def; this.min = min; this.max = max; this.step = step;
    }

    public void cycle() {
        value += step;
        if (value > max + 1e-9) value = min;
    }

    public int i() { return (int) Math.round(value); }
    public boolean on() { return value >= 0.5; }

    public String display() {
        return value == Math.rint(value) ? String.valueOf((int) value) : String.format("%.2f", value);
    }
}
