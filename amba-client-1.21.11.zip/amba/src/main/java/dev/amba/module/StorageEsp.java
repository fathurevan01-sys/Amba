package dev.amba.module;

import dev.amba.util.Esp;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

public class StorageEsp extends Module {
    private final Setting range = num("Range", 128, 32, 256, 32);

    public StorageEsp() { super("StorageESP"); }
    @Override public boolean usesScanner() { return true; }

    @Override
    public void onHud(GuiGraphics g, float pt) {
        for (Scanner.Hit h : Scanner.hits) {
            Vec3 c = Vec3.atCenterOf(h.pos());
            if (Esp.distTo(c, pt) > range.value) continue;
            Esp.box(g, new AABB(h.pos()), h.color(), null, pt);
        }
    }
}
