package dev.amba.module;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;

import java.util.ArrayList;
import java.util.List;

public abstract class Module {
    protected final Minecraft mc = Minecraft.getInstance();
    public final String name;
    public boolean enabled;
    public final List<Setting> settings = new ArrayList<>();

    protected Module(String name) { this.name = name; }

    protected Setting num(String n, double def, double min, double max, double step) {
        Setting s = new Setting(n, def, min, max, step);
        settings.add(s);
        return s;
    }

    public void toggle() { set(!enabled); }

    public void set(boolean v) {
        if (v == enabled) return;
        enabled = v;
        if (v) onEnable(); else onDisable();
    }

    public void onEnable() {}
    public void onDisable() {}
    /** Start of client tick (before input is read). */
    public void onPreTick() {}
    public void onTick() {}
    public void onHud(GuiGraphics g, float pt) {}
    public void onDisconnect() { set(false); }
    /** Whether this module needs the shared block-entity scanner running. */
    public boolean usesScanner() { return false; }
}
