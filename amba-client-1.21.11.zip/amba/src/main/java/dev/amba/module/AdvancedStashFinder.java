package dev.amba.module;

import dev.amba.util.Esp;
import dev.amba.util.Util;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.phys.AABB;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.time.LocalDateTime;
import java.util.*;

/**
 * Weighted + clustered stash detection.
 *  - score: chest/barrel 1, shulker 3, hopper/dispenser 0.5, furnace 0.25
 *  - stashes that span chunk borders are caught by summing the 3x3 neighbourhood
 *  - only the local-maximum chunk of a cluster is reported (no duplicate spam)
 *  - results are appended to <gameDir>/amba_stashes.txt
 */
public class AdvancedStashFinder extends Module {
    private final Setting threshold = num("Score", 20, 5, 200, 5);
    private final Setting log = num("Log", 1, 0, 1, 1);
    private final Setting chat = num("Chat", 1, 0, 1, 1);
    private final Set<Long> reported = new HashSet<>();
    private List<Scanner.Chunk> found = new ArrayList<>();
    private int ver = -1;

    public AdvancedStashFinder() { super("AdvStashFinder"); }
    @Override public boolean usesScanner() { return true; }
    @Override public void onEnable() { reported.clear(); found = new ArrayList<>(); ver = -1; }

    @Override
    public void onTick() {
        if (ver == Scanner.version) return;
        ver = Scanner.version;
        Map<Long, Scanner.Chunk> all = Scanner.chunks;
        List<Scanner.Chunk> f = new ArrayList<>();
        for (Scanner.Chunk c : all.values()) {
            double sum = 0;
            boolean top = true;
            for (int dx = -1; dx <= 1; dx++)
                for (int dz = -1; dz <= 1; dz++) {
                    Scanner.Chunk n = all.get(Util.key(c.cx + dx, c.cz + dz));
                    if (n == null) continue;
                    sum += n.score();
                    if (n.score() > c.score()) top = false;
                }
            c.cluster = sum;
            if (top && sum >= threshold.value) f.add(c);
        }
        f.sort((a, b) -> Double.compare(b.cluster, a.cluster));
        found = f;
        for (Scanner.Chunk c : f) {
            if (!reported.add(c.key())) continue;
            String line = String.format("score=%.1f chunk=%d,%d pos=~%d,%d storage=%d shulkers=%d hoppers=%d",
                    c.cluster, c.cx, c.cz, c.blockX(), c.blockZ(), c.storage(), c.shulkers, c.hoppers);
            if (chat.on()) Util.chat("\u00a76Stash\u00a7r " + line);
            if (log.on()) write(line);
        }
    }

    private void write(String line) {
        try {
            Path p = FabricLoader.getInstance().getGameDir().resolve("amba_stashes.txt");
            String dim = mc.level == null ? "?" : mc.level.dimension().toString();
            Files.writeString(p, LocalDateTime.now() + " " + dim + " " + line + System.lineSeparator(),
                    StandardOpenOption.CREATE, StandardOpenOption.APPEND);
        } catch (IOException ignored) {}
    }

    @Override
    public void onHud(GuiGraphics g, float pt) {
        int y = 30;
        int shown = 0;
        for (Scanner.Chunk c : found) {
            AABB b = new AABB(c.cx * 16, c.minY == Integer.MAX_VALUE ? c.allMinY : c.minY, c.cz * 16,
                    c.cx * 16 + 16, (c.maxY == Integer.MIN_VALUE ? c.allMaxY : c.maxY) + 1, c.cz * 16 + 16);
            Esp.box(g, b, 0xFFFF5555, String.format("STASH %.0f", c.cluster), pt);
            if (shown++ < 5) {
                g.drawString(mc.font, String.format("%.0f  @ %d, %d", c.cluster, c.blockX(), c.blockZ()), 6, y, 0xFFFF7777, true);
                y += 10;
            }
        }
    }
}
