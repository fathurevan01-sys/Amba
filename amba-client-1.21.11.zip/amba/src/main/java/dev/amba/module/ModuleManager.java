package dev.amba.module;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public final class ModuleManager {
    private ModuleManager() {}

    public static final List<Module> MODULES = new ArrayList<>();
    private static int ticks;

    public static void init() {
        MODULES.add(new ChunkFinder());
        MODULES.add(new StorageEsp());
        MODULES.add(new StashFinder());
        MODULES.add(new AdvancedStashFinder());
        MODULES.add(new AmethystEsp());
        MODULES.add(new Freecam());
        MODULES.add(new SpeedMine());
        MODULES.add(new BreakDelay());
    }

    public static void preTick() {
        for (Module m : MODULES) if (m.enabled) m.onPreTick();
    }

    public static void tick() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null) return;
        boolean scan = false;
        for (Module m : MODULES) if (m.enabled && m.usesScanner()) scan = true;
        if (scan && ticks++ % 20 == 0) Scanner.scan();
        for (Module m : MODULES) if (m.enabled) m.onTick();
    }

    public static void hud(GuiGraphics g, float pt) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null || mc.options.hideGui) return;
        for (Module m : MODULES) if (m.enabled) m.onHud(g, pt);

        // active-module list (top right)
        int w = mc.getWindow().getGuiScaledWidth();
        int y = 4;
        List<Module> on = new ArrayList<>();
        for (Module m : MODULES) if (m.enabled) on.add(m);
        on.sort(Comparator.comparingInt((Module m) -> -mc.font.width(m.name)));
        for (Module m : on) {
            g.drawString(mc.font, m.name, w - mc.font.width(m.name) - 4, y, 0xFFB98CFF, true);
            y += 10;
        }
    }

    public static void onDisconnect() {
        for (Module m : MODULES) m.onDisconnect();
        Scanner.clear();
        ticks = 0;
    }
}
