package dev.amba.module;

import dev.amba.util.Util;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.block.entity.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Shared scan of block entities in loaded chunks; feeds StorageESP / ChunkFinder / StashFinder. */
public final class Scanner {
    private Scanner() {}

    public record Hit(BlockPos pos, int color) {}

    public static final class Chunk {
        public final int cx, cz;
        public int chests, barrels, shulkers, hoppers, dispensers, furnaces, others, total;
        public int minY = Integer.MAX_VALUE, maxY = Integer.MIN_VALUE;   // storage y-range
        public int allMinY = Integer.MAX_VALUE, allMaxY = Integer.MIN_VALUE; // any BE y-range
        public double cluster;

        Chunk(int cx, int cz) { this.cx = cx; this.cz = cz; }

        public int storage() { return chests + barrels + shulkers; }

        public double score() {
            return chests + barrels + shulkers * 3.0 + hoppers * 0.5 + dispensers * 0.5 + furnaces * 0.25;
        }

        public long key() { return Util.key(cx, cz); }
        public int blockX() { return cx * 16 + 8; }
        public int blockZ() { return cz * 16 + 8; }
    }

    public static volatile List<Hit> hits = new ArrayList<>();
    public static volatile Map<Long, Chunk> chunks = new HashMap<>();
    /** Incremented on every completed scan; modules compare against it. */
    public static int version = 0;

    public static void scan() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null) return;
        int r = Math.min(mc.options.getEffectiveRenderDistance(), 12);
        int pcx = mc.player.blockPosition().getX() >> 4, pcz = mc.player.blockPosition().getZ() >> 4;

        List<Hit> h = new ArrayList<>();
        Map<Long, Chunk> m = new HashMap<>();

        for (int dx = -r; dx <= r; dx++)
            for (int dz = -r; dz <= r; dz++) {
                LevelChunk c = mc.level.getChunkSource().getChunkNow(pcx + dx, pcz + dz);
                if (c == null) continue;
                Chunk info = new Chunk(pcx + dx, pcz + dz);
                for (BlockEntity be : c.getBlockEntities().values()) {
                    int y = be.getBlockPos().getY();
                    boolean storage = true;
                    if (be instanceof TrappedChestBlockEntity) { info.chests++; h.add(new Hit(be.getBlockPos(), 0xFFFF4040)); }
                    else if (be instanceof ChestBlockEntity) { info.chests++; h.add(new Hit(be.getBlockPos(), 0xFFFFA020)); }
                    else if (be instanceof BarrelBlockEntity) { info.barrels++; h.add(new Hit(be.getBlockPos(), 0xFFB07030)); }
                    else if (be instanceof ShulkerBoxBlockEntity) { info.shulkers++; h.add(new Hit(be.getBlockPos(), 0xFFFF55FF)); }
                    else if (be instanceof EnderChestBlockEntity) { storage = false; info.others++; h.add(new Hit(be.getBlockPos(), 0xFFA050FF)); }
                    else if (be instanceof HopperBlockEntity) { storage = false; info.hoppers++; h.add(new Hit(be.getBlockPos(), 0xFF909090)); }
                    else if (be instanceof DispenserBlockEntity) { storage = false; info.dispensers++; h.add(new Hit(be.getBlockPos(), 0xFF707070)); }
                    else if (be instanceof AbstractFurnaceBlockEntity) { storage = false; info.furnaces++; }
                    else if (be instanceof BrewingStandBlockEntity || be instanceof BedBlockEntity
                            || be instanceof SignBlockEntity || be instanceof ChiseledBookShelfBlockEntity
                            || be instanceof DecoratedPotBlockEntity) { storage = false; info.others++; }
                    else continue;
                    info.total++;
                    info.allMinY = Math.min(info.allMinY, y);
                    info.allMaxY = Math.max(info.allMaxY, y);
                    if (storage) { info.minY = Math.min(info.minY, y); info.maxY = Math.max(info.maxY, y); }
                }
                if (info.total > 0) m.put(info.key(), info);
            }
        hits = h;
        chunks = m;
        version++;
    }

    public static void clear() {
        hits = new ArrayList<>();
        chunks = new HashMap<>();
        version++;
    }
}
