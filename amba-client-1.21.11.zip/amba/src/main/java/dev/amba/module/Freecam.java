package dev.amba.module;

import com.mojang.authlib.GameProfile;
import dev.amba.util.Util;
import net.minecraft.client.player.RemotePlayer;
import org.lwjgl.glfw.GLFW;

import java.util.UUID;

/**
 * Detached camera. A client-only RemotePlayer becomes the camera entity; the real player is
 * frozen by releasing the movement keys each tick. Mouse look still turns the real player
 * (and the camera copies it), so avoid combat/interaction while active.
 */
public class Freecam extends Module {
    private final Setting speed = num("Speed", 1.0, 0.5, 5.0, 0.5);
    private RemotePlayer cam;

    public Freecam() { super("Freecam"); }

    @Override
    public void onEnable() {
        if (mc.player == null || mc.level == null) { enabled = false; return; }
        cam = new RemotePlayer(mc.level, new GameProfile(UUID.randomUUID(), "Freecam"));
        double x = mc.player.getX(), y = mc.player.getY(), z = mc.player.getZ();
        cam.setPos(x, y, z);
        cam.xo = x; cam.yo = y; cam.zo = z;
        cam.setYRot(mc.player.getYRot()); cam.setXRot(mc.player.getXRot());
        cam.yRotO = cam.getYRot(); cam.xRotO = cam.getXRot();
        mc.setCameraEntity(cam);
    }

    @Override
    public void onDisable() {
        if (mc.player != null) mc.setCameraEntity(mc.player);
        cam = null;
    }

    @Override
    public void onPreTick() {
        if (mc.screen != null) return;
        mc.options.keyUp.setDown(false);
        mc.options.keyDown.setDown(false);
        mc.options.keyLeft.setDown(false);
        mc.options.keyRight.setDown(false);
        mc.options.keyJump.setDown(false);
        mc.options.keyShift.setDown(false);
    }

    @Override
    public void onTick() {
        if (cam == null || mc.player == null) return;
        cam.yRotO = cam.getYRot(); cam.xRotO = cam.getXRot();
        cam.setYRot(mc.player.getYRot()); cam.setXRot(mc.player.getXRot());
        if (mc.screen != null) return;

        double yaw = Math.toRadians(cam.getYRot());
        double fx = -Math.sin(yaw), fz = Math.cos(yaw);
        double rx = -Math.cos(yaw), rz = -Math.sin(yaw);
        double mx = 0, my = 0, mz = 0;
        if (Util.keyDown(GLFW.GLFW_KEY_W)) { mx += fx; mz += fz; }
        if (Util.keyDown(GLFW.GLFW_KEY_S)) { mx -= fx; mz -= fz; }
        if (Util.keyDown(GLFW.GLFW_KEY_D)) { mx += rx; mz += rz; }
        if (Util.keyDown(GLFW.GLFW_KEY_A)) { mx -= rx; mz -= rz; }
        if (Util.keyDown(GLFW.GLFW_KEY_SPACE)) my += 1;
        if (Util.keyDown(GLFW.GLFW_KEY_LEFT_SHIFT)) my -= 1;
        double len = Math.sqrt(mx * mx + my * my + mz * mz);
        if (len > 0) { mx /= len; my /= len; mz /= len; }
        double s = 0.5 * speed.value;
        cam.xo = cam.getX(); cam.yo = cam.getY(); cam.zo = cam.getZ();
        cam.setPos(cam.getX() + mx * s, cam.getY() + my * s, cam.getZ() + mz * s);
    }
}
