package dev.amba.module;

import dev.amba.util.Esp;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.chunk.LevelChunkSection;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.List;

/** Finds budding amethyst, clusters and buds (i.e. geodes) in loaded chunks. */
public class AmethystEsp extends Module {
    private record Found(BlockPos pos, int color) {}

    private final Setting chunks = num("Chunks", 6, 2, 12, 1);
    private final Setting range = num("Range", 128, 32, 256, 32);
    private volatile List<Found> found = new ArrayList<>();
    private int t;

    public AmethystEsp() { super("AmethystESP"); }
    @Override public void onEnable() { t = 0; }
    @Override public void onDisable() { found = new ArrayList<>(); }

    private static boolean match(BlockState s) {
        return s.is(Blocks.BUDDING_AMETHYST) || s.is(Blocks.AMETHYST_CLUSTER)
                || s.is(Blocks.LARGE_AMETHYST_BUD) || s.is(Blocks.MEDIUM_AMETHYST_BUD) || s.is(Blocks.SMALL_AMETHYST_BUD);
    }

    @Override
    public void onTick() {
        if (t++ % 60 != 0 || mc.level == null || mc.player == null) return;
        int r = chunks.i();
        int pcx = mc.player.blockPosition().getX() >> 4, pcz = mc.player.blockPosition().getZ() >> 4;
        List<Found> out = new ArrayList<>();
        for (int dx = -r; dx <= r; dx++)
            for (int dz = -r; dz <= r; dz++) {
                LevelChunk c = mc.level.getChunkSource().getChunkNow(pcx + dx, pcz + dz);
                if (c == null) continue;
                LevelChunkSection[] secs = c.getSections();
                for (int i = 0; i < secs.length; i++) {
                    LevelChunkSection s = secs[i];
                    if (s == null || s.hasOnlyAir() || !s.maybeHas(AmethystEsp::match)) continue;
                    int by = (c.getMinSectionY() + i) << 4;
                    for (int x = 0; x < 16; x++)
                        for (int y = 0; y < 16; y++)
                            for (int z = 0; z < 16; z++) {
                                BlockState st = s.getBlockState(x, y, z);
                                if (!match(st)) continue;
                                int col = st.is(Blocks.BUDDING_AMETHYST) ? 0xFFFF66FF
                                        : st.is(Blocks.AMETHYST_CLUSTER) ? 0xFFD9A3FF : 0xFF9A6BD1;
                                out.add(new Found(new BlockPos((pcx + dx) * 16 + x, by + y, (pcz + dz) * 16 + z), col));
                                if (out.size() > 3000) { found = out; return; }
                            }
                }
            }
        found = out;
    }

    @Override
    public void onHud(GuiGraphics g, float pt) {
        for (Found f : found) {
            if (Esp.distTo(Vec3.atCenterOf(f.pos()), pt) > range.value) continue;
            Esp.box(g, new AABB(f.pos()), f.color(), null, pt);
        }
    }
}
