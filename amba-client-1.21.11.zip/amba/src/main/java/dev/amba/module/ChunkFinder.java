package dev.amba.module;

import dev.amba.util.Esp;
import dev.amba.util.Util;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.phys.AABB;

import java.util.HashSet;
import java.util.Set;

/** Highlights chunks holding player-made block entities (storage, furnaces, beds, signs, ...). */
public class ChunkFinder extends Module {
    private final Setting min = num("MinBlocks", 5, 1, 50, 1);
    private final Setting chat = num("Chat", 1, 0, 1, 1);
    private final Set<Long> reported = new HashSet<>();
    private int ver = -1;

    public ChunkFinder() { super("ChunkFinder"); }
    @Override public boolean usesScanner() { return true; }
    @Override public void onEnable() { reported.clear(); ver = -1; }

    @Override
    public void onTick() {
        if (ver == Scanner.version) return;
        ver = Scanner.version;
        if (!chat.on()) return;
        for (Scanner.Chunk c : Scanner.chunks.values())
            if (c.total >= min.i() && reported.add(c.key()))
                Util.chat("Active chunk " + c.cx + "," + c.cz + " (~" + c.blockX() + ", " + c.blockZ() + ") blocks=" + c.total);
    }

    @Override
    public void onHud(GuiGraphics g, float pt) {
        for (Scanner.Chunk c : Scanner.chunks.values()) {
            if (c.total < min.i()) continue;
            AABB b = new AABB(c.cx * 16, c.allMinY, c.cz * 16, c.cx * 16 + 16, c.allMaxY + 1, c.cz * 16 + 16);
            Esp.box(g, b, 0xFF55FFFF, c.cx + "," + c.cz + " [" + c.total + "]", pt);
        }
    }
}
