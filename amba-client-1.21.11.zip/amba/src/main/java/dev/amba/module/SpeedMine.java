package dev.amba.module;

import dev.amba.mixin.MultiPlayerGameModeAccessor;

/** Multiplies per-tick block-breaking progress. Anti-cheat servers will flag this. */
public class SpeedMine extends Module {
    private final Setting mult = num("Multiplier", 1.5, 1.0, 4.0, 0.5);
    private float last;

    public SpeedMine() { super("SpeedMine"); }

    @Override
    public void onTick() {
        if (mc.gameMode == null) return;
        MultiPlayerGameModeAccessor a = (MultiPlayerGameModeAccessor) mc.gameMode;
        if (!mc.gameMode.isDestroying()) { last = 0; return; }
        float p = a.zGetProgress();
        float delta = p - last;
        if (delta > 0 && delta < 0.9f) {
            p += delta * (float) (mult.value - 1.0);
            a.zSetProgress(p);
        }
        last = p;
    }
}
