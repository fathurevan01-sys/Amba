package dev.amba;

import dev.amba.gui.ClickGui;
import dev.amba.module.ModuleManager;
import dev.amba.util.Util;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.Minecraft;
import org.lwjgl.glfw.GLFW;

public class AmbaClient implements ClientModInitializer {
    private boolean keyWasDown;
    private boolean stickySet;
    /** Set by the key poll (every frame) or by the /amba command; consumed on the next tick. */
    private volatile boolean toggleRequested;

    @Override
    public void onInitializeClient() {
        ModuleManager.init();

        // /amba works on every platform (phones, no keyboard, launchers with odd key handling)
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
                dispatcher.register(ClientCommandManager.literal("amba").executes(ctx -> {
                    toggleRequested = true;
                    return 1;
                })));

        ClientTickEvents.START_CLIENT_TICK.register(mc -> ModuleManager.preTick());

        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            if (toggleRequested) {
                toggleRequested = false;
                if (mc.level != null) {
                    if (mc.screen instanceof ClickGui) mc.setScreen(null);
                    else if (mc.screen == null) mc.setScreen(new ClickGui());
                }
            }
            ModuleManager.tick();
        });

        // Keys are polled every FRAME (not every tick) so short taps on on-screen buttons are not missed.
        HudRenderCallback.EVENT.register((g, dt) -> {
            pollOpenKey();
            ModuleManager.hud(g, dt.getGameTimeDeltaPartialTick(true));
        });

        ClientPlayConnectionEvents.DISCONNECT.register((handler, mc) -> ModuleManager.onDisconnect());
    }

    private void pollOpenKey() {
        try {
            if (!stickySet) {
                GLFW.glfwSetInputMode(Util.handle(), GLFW.GLFW_STICKY_KEYS, GLFW.GLFW_TRUE);
                stickySet = true;
            }
        } catch (Throwable ignored) { stickySet = true; }
        boolean down = Util.keyDown(GLFW.GLFW_KEY_CAPS_LOCK)
                || Util.keyDown(GLFW.GLFW_KEY_RIGHT_SHIFT)
                || Util.keyDown(GLFW.GLFW_KEY_GRAVE_ACCENT);
        if (down && !keyWasDown) toggleRequested = true;
        keyWasDown = down;
    }
}
