package dev.amba.mixin;

import net.minecraft.client.multiplayer.MultiPlayerGameMode;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(MultiPlayerGameMode.class)
public interface MultiPlayerGameModeAccessor {
    @Accessor("destroyDelay") int zGetDestroyDelay();
    @Accessor("destroyDelay") void zSetDestroyDelay(int v);
    @Accessor("destroyProgress") float zGetProgress();
    @Accessor("destroyProgress") void zSetProgress(float v);
}
